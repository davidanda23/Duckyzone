import { StringMap } from '@angular/compiler/src/compiler_facade_interface';

export class EmployeeModel{
    id: number;
    correo: String;
    nombre: String;
    tel: number;
    apelli_pat: String;
    apelli_mat:String;
    nombreusuario: String;
    salario: number;
    puesto: String;
    id_departamento: number;
    id_usuario: number;
}